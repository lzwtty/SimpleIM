#pragma once

template<class T>
class CList
{
public:
	struct NODE
	{
		NODE()
		{
			pNext = NULL;
			pLast = NULL;
		}

		T Data;
		NODE *pNext;
		NODE *pLast;
	};

	class Iterator
	{
	public:
		Iterator()
		{
			m_pNode = NULL;
		}

		Iterator(NODE *pNode)
		{
			m_pNode = pNode;
		}

		Iterator& operator ++()
		{
			m_pNode = m_pNode->pNext;

			return *this;
		}

		Iterator operator ++(int)
		{
			Iterator obj = *this;
			m_pNode = m_pNode->pNext;

			return obj;
		}

		Iterator& operator --()
		{
			m_pNode = m_pNode->pLast;

			return *this;
		}

		Iterator operator --(int)
		{
			Iterator obj = *this;
			m_pNode = m_pNode->pLast;

			return obj;
		}

		operator NODE*() const
		{
			return m_pNode;
		}

		T& operator *() const
		{
			return m_pNode->Data;
		}

		T* operator->() const
		{
			return &(m_pNode->Data);
		}

		bool operator ==(NODE *pNode) const
		{
			return (m_pNode == pNode) ? true : false;
		}

		bool operator ==(const Iterator &r) const
		{
			return (m_pNode == r.m_pNode) ? true : false;
		}

		bool operator !=(NODE *pNode) const
		{
			return (m_pNode != pNode) ? true : false;
		}

		bool operator !=(const Iterator &r) const
		{
			return (m_pNode != r.m_pNode) ? true : false;
		}

		friend bool operator ==(NODE* pNode, const Iterator &r)
		{
			return r == pNode;
		}

		friend bool operator !=(NODE* pNode, const Iterator &r)
		{
			return r != pNode;
		}

		bool IsEmpty() const
		{
			return (m_pNode == NULL) ? true : false;
		}

	private:
		NODE *m_pNode;
	};

	CList()
	{
		m_pHead = NULL;
		m_pEnd = NULL;
	}

	~CList()
	{
		Clerk();
	}

	Iterator AddEnd()
	{
		NODE *pNew = new NODE;
		if (NULL != pNew)
		{
			if (NULL == m_pEnd)
			{
				m_pHead = pNew;
			}
			else
			{
				m_pEnd->pNext = pNew;
				pNew->pLast = m_pEnd;
			}

			m_pEnd = pNew;
		}

		return Iterator(pNew);
	}

	Iterator AddHead()
	{
		NODE *pNew = new NODE;
		if (NULL != pNew)
		{
			if (NULL == m_pHead)
			{
				m_pEnd = pNew;
			}
			else
			{
				m_pHead->pLast = pNew;
				pNew->pNext = m_pHead;
			}

			m_pHead = pNew;
		}

		return Iterator(pNew);
	}

	Iterator InsertHead(const Iterator &r)
	{
		NODE *pNew = NULL;
		if (!r.IsEmpty())
		{
			pNew = new NODE;
			if (NULL != pNew)
			{
				NODE *pNode = (NODE*)r;
				if (NULL == pNode->pLast)
				{
					m_pHead = pNew;
				}
				else
				{
					pNode->pLast->pNext = pNew;
					pNew->pLast = pNode->Last;
				}

				pNode->pLast = pNew;
				pNew->pNext = pNode;
			}
		}

		return Iterator(pNew);
	}

	Iterator InsertEnd(const Iterator &r)
	{
		NODE *pNew = NULL;
		if (!r.IsEmpty())
		{
			pNew = new NODE;
			if (NULL != pNew)
			{
				NODE *pNode = (NODE*)r;
				if (NULL == pNode->pNext)
				{
					m_pEnd = pNew;
				}
				else
				{
					pNode->Next->pLast = pNew;
					pNew->pNext = pNode->pNext;
				}

				pNode->pNext = pNew;
				pNew->pLast = pNode;
			}
		}

		return Iterator(pNew);
	}

	int DeleteNode(const Iterator &r)
	{
		if (NULL == m_pHead)
		{
			return -1;
		}
		if (r.IsEmpty())
		{
			return -2;
		}

		NODE *pNode = (NODE*)r;

		if (NULL == pNode->pLast)
		{
			m_pHead = m_pHead->pNext;
			if (NULL == m_pHead)
			{
				m_pEnd = NULL;
			}
			else
			{
				m_pHead->pLast = NULL;
			}
		}
		else
		{
			if (NULL != pNode->pNext)
			{
				pNode->pNext->pLast = pNode->pLast;
			}
			pNode->pLast->pNext = pNode->pNext;
		}

		delete pNode;

		return 0;
	}

	int Clerk()
	{
		if (NULL == m_pHead)
		{
			return -1;
		}

		NODE *pTemp = NULL;
		while (NULL != m_pHead)
		{
			pTemp = m_pHead;
			m_pHead = m_pHead->pNext;
			delete pTemp;
		}

		m_pEnd = m_pHead;

		return 0;
	}

	Iterator Begin()
	{
		return Iterator(m_pHead);
	}

	Iterator End()
	{
		return Iterator(NULL);
	}

	bool IsEmpty()
	{
		return m_pHead == NULL ? true : false;
	}

private:
	NODE *m_pHead;
	NODE *m_pEnd;
};

template <class T, class D>
T& FindNode(T &rBegin, T &rEnd, const D Data)
{
	while (rBegin != rEnd)
	{
		if (*rBegin == Data)
		{
			break;
		}

		rBegin++;
	}

	return rBegin;
}
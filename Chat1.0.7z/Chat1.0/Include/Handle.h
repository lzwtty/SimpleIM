#ifndef __HANDLE_H__
#define __HANDLE_H__

#include <WINSOCK2.H>

struct DATA
{
	SOCKET sock;
	TCHAR szBuf[4096];
};

typedef int(*PFN)(DATA *pData);

struct PROTO_MAP
{
	int nProto;
	PFN pfnProto;
};

#define BEGIN_MAP(name) PROTO_MAP g_##name[] = {

#define MAP(proto, pfn) {proto, pfn},

#define END_MAP() {NULL ,NULL}};

#define CALL_MAP(name) g_##name

#define IMPLEMENT_HANDLE(name)\
DWORD WINAPI name##HandleProc( LPVOID lpParameter)\
{\
	DATA *pData = (DATA*)lpParameter;\
	if (NULL != pData)\
	{\
		PROTO_MAP *pTemp = CALL_MAP(name);\
\
		while (pTemp->nProto != NULL)\
		{\
			if (pTemp->nProto == *(int*)(pData->szBuf))\
			{\
				pTemp->pfnProto(pData);\
				break;\
			}\
\
			pTemp++;\
		}\
	}\
\
	return 0;\
}

#define CALL_HANDLE(name) name##HandleProc

#define DELCARE_THREADPROC(name) DWORD WINAPI name##Proc(LPVOID lpParameter);

#define IMPLEMENT_THREADPROC(name)\
IMPLEMENT_HANDLE(name)\
DWORD WINAPI name##Proc(LPVOID lpParameter)\
{\
	SOCKET socket = (SOCKET)lpParameter;\
\
	DATA *pNew = NULL;\
	do\
	{\
		pNew = new DATA;\
	} while (NULL == pNew);\
\
	DWORD dwThreadID = 0;\
	while (-1 != recv(socket, pNew->szBuf, 4096, 0))\
	{\
		pNew->sock = socket;\
		CloseHandle(CreateThread(NULL, NULL, CALL_HANDLE(name), (LPVOID)pNew, 0, &dwThreadID));\
		do\
		{\
			pNew = new DATA;\
		} while (NULL == pNew);\
	}\
\
	return 0;\
}

#define CALL_THREADPROC(name) name##Proc

#endif
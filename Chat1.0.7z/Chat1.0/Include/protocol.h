#pragma once

#define PROTO_LOGIN 1
#define PROTO_REGIST 2
#define PROTO_REGIST__RES 3
#define PROTO_LOGIN_RES 4
#define PROTO_LOGIN_NTY 5
#define PROTO_CHECH_USER 6
#define PROTO_CHECH_USER_RES 7
#define PROTO_FRIENDLIST 8
#define PROTO_FRIENDLIST_RES 9
#define PROTO_ADD_FRIENDT 10
#define PROTO_ADD_FRIE_RES 11
#define PROTO_ALL_FRIENDLIST 12
#define PROTO_ALL_FRIEND_RES 13
#define PROTO_LOGOUT 14
#define PROTO_LOGOUT_NTY 15
#define PROTO_SEND 16
#define PROTO_MODIFY 17

struct USER
{
	char szName[20];
	char szPass[20];
};

struct PACK_LOGIN
{
	int nNty;
	USER uUser;
};

struct PACK_RES
{
	int nNty;
	int nRes;
};

struct PACK_CHECK_USER
{
	int nNty;
	char szUser[40];
};

struct PACK_REG
{
	int nNty;
	USER uUser;
	bool bSex;
	char szName[20];
};

struct PACK_FRIENDLIST
{
	int nNty;
	int nSize;
	int nCount;
	char szFriend[];
};

struct PACK_ADDFIREND
{
	int nNty;
	char szDest[20];
	char szSour[20];
};

struct PACK_ADDFIREND_RES
{
	int nNty;
	char szDest[20];
	char szSour[20];
	int nRes;
};

struct PACK_SEND
{
	int nNty;
	char szDest[20];
	char szSour[20];
	char szBuf[255];
};

struct PACK_MODIFY
{
	int nNty;
	char szPass[20];
	bool bSex;
	char szName[20];
};
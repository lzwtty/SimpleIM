#pragma once

#include "MsgMap.h"

DELCARE_DLGPROC(Register)
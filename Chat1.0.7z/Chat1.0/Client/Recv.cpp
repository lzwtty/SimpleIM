#include "Recv.h"



CRecv::CRecv()
{

}


CRecv::~CRecv()
{
}

CString& CRecv::GetMsg()
{
	return m_Msg;
}
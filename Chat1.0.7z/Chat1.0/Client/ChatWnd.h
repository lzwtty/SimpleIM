#pragma once

#include "Recv.h"
#include "../Include/CList.h"

class CChatWnd
{
public:
	CChatWnd();
	~CChatWnd();

	struct DATA
	{
		DATA()
		{
			hWnd = NULL;
		}

		CString szUser;
		CString szName;
		HWND hWnd;
		CList<CRecv> m_Recv;
	};

	DATA& GetData();

	bool operator ==(const TCHAR *pStr);

private:
	DATA m_Data;
};


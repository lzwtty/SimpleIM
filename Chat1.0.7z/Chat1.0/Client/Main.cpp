#include "StdAfx.h"
#include "Main.h"
#include "NetThread.h"
#include "Login.h"
#include "AddFirList.h"
#include "Chat.h"
#include "Modify.h"

BOOL OnMainInitDialog(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnMainCommand(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnMainMeasItem(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnMainDrawItem(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnMainClose(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnMainTimer(HWND hDlg, WPARAM wParam, LPARAM lParam);

BEGIN_MSG_MAP(Main)
	MAP(WM_INITDIALOG, OnMainInitDialog)
	MAP(WM_COMMAND, OnMainCommand)
	MAP(WM_DRAWITEM, OnMainDrawItem)
	MAP(WM_MEASUREITEM, OnMainMeasItem)
	MAP(WM_TIMER, OnMainTimer)
	MAP(WM_CLOSE, OnMainClose)
END_MSG_MAP()

IMPLEMENT_DLGPROC(Main)

SOCKET g_Sock;
HWND g_Main;

BOOL OnMainInitDialog(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	g_Main = hDlg;
	WSADATA wd;
	WSAStartup(0x0202, &wd);

	SOCKET sockClient = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	if (INVALID_SOCKET == sockClient)
	{
		SendMessage(hDlg, WM_CLOSE, 0, 0);
	}

	SOCKADDR_IN sockAddr;
	sockAddr.sin_family = AF_INET;
	sockAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	sockAddr.sin_port = htons(4396);

	if (SOCKET_ERROR == connect(sockClient, (sockaddr*)&sockAddr, sizeof(SOCKADDR_IN)))
	{
		closesocket(sockClient);
		SendMessage(hDlg, WM_CLOSE, 0, 0);
	}
	else
	{
		g_Sock = sockClient;
		CloseHandle(CreateThread(NULL, NULL, CALL_THREADPROC(Client), (LPVOID)sockClient, 0, NULL));

		int nCount = 0;
		int nRes = 0;

		while (nCount < 3)
		{
			nRes = DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DLG_LOGIN), hDlg, CALL_DLGPROC(Login));
			if (nRes == WM_CLOSE)
			{
				nCount++;
			}
			else
			{
				break;
			}
		}

		if (nCount == 3)
		{
			SendMessage(hDlg, WM_CLOSE, NULL, NULL);
		}
	}

	SetTimer(hDlg, 1, 200, NULL);
	return TRUE;
}

BOOL OnMainClose(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	PACK_RES *pPack = new PACK_RES;

	pPack->nNty = PROTO_LOGOUT;

	send(g_Sock, (char*)pPack, 4, 0);

	WSACleanup();
	EndDialog(hDlg, WM_CLOSE);

	return TRUE;
}

BOOL OnMainCommand(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	int nNty = HIWORD(wParam);
	int nID = LOWORD(wParam);

	if (BN_CLICKED == nNty)
	{
		if (nID == IDC_BTN_MADDFRIEND)
		{
			PACK_RES *pPack = new PACK_RES;

			pPack->nNty = PROTO_ALL_FRIENDLIST;

			CreateDialog(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DLG_ADDFRI), hDlg, CALL_DLGPROC(AddFriList));

			send(g_Sock, (char*)pPack, sizeof(PACK_RES), 0);

			delete pPack;

		}

		if (nID == IDC_BTN_MODIFY)
		{
			DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DLG_MODIFY), hDlg, CALL_DLGPROC(Modify));
		}
	}

	if (LBN_DBLCLK == nNty)
	{
		if (nID == IDC_LIST1)
		{
			int nIndex = SendDlgItemMessage(hDlg, IDC_LIST1, LB_GETCURSEL, 0, 0);

			TCHAR szBuf[40] = "";

			SendDlgItemMessage(hDlg, IDC_LIST1, LB_GETTEXT, nIndex, (LPARAM)szBuf);

			TCHAR szUser[20] = "";
			TCHAR szName[20] = "";
			int j = 0;
			int z = 0;
			bool bFlag = false;
			for (int i = 0; '\0' != szBuf[i]; i++)
			{
				if (')' == szBuf[i])
				{
					bFlag = false;
					szUser[j] = '\0';
					break;
				}

				if (bFlag)
				{
					szUser[j] = szBuf[i];
					j++;
				}
				else
				{
					szName[z] = szBuf[i];
					z++;
				}

				if ('(' == szBuf[i])
				{
					szName[z - 1] = '\0';
					bFlag = true;
				}
			}

			CList<CChatWnd>::Iterator iBegin = g_Chat.Begin();
			CList<CChatWnd>::Iterator iEnd = g_Chat.End();

			CList<CChatWnd>::Iterator iTemp = FindNode(iBegin, iEnd, szUser);

			if ((*iTemp).GetData().hWnd == NULL)
			{
				(*iTemp).GetData().hWnd = CreateDialog(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DLG_CHAT), hDlg, CALL_DLGPROC(Chat));
				ShowWindow((*iTemp).GetData().hWnd, SW_SHOW);

				SetWindowText((*iTemp).GetData().hWnd, szUser);
			}
			else
			{
				SetWindowPos((*iTemp).GetData().hWnd, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
			}

			SendMessage((*iTemp).GetData().hWnd, WM_OK, 0, (LPARAM)szName);

			InvalidateRect(GetDlgItem(hDlg, IDC_LIST1), NULL, TRUE);
		}
	}

	return TRUE;
}

BOOL OnMainMeasItem(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	LPMEASUREITEMSTRUCT lpItem = (LPMEASUREITEMSTRUCT)lParam;

	lpItem->itemHeight = 32;

	return TRUE;
}

BOOL OnMainDrawItem(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	LPDRAWITEMSTRUCT lpDis = (LPDRAWITEMSTRUCT)lParam;

	if (lpDis->CtlType == ODT_LISTBOX)
	{
		if (lpDis->itemAction == ODA_DRAWENTIRE || ODA_SELECT == lpDis->itemAction)
		{
			HBRUSH hBrush = 0;
			if (lpDis->itemState & ODS_SELECTED)
			{
				hBrush = CreateSolidBrush(RGB(0, 0, 255));

				SetBkColor(lpDis->hDC, RGB(0, 0, 255));
				SetTextColor(lpDis->hDC, RGB(255, 255, 255));
			}
			else
			{
				hBrush = CreateSolidBrush(RGB(255, 255, 255));
			}

			FillRect(lpDis->hDC, &(lpDis->rcItem), hBrush);
			DeleteObject(hBrush);

			HBITMAP hBmp;

			lpDis->itemData;

			if (lpDis->itemData & 1)
			{
				if (lpDis->itemData & 2)
				{
					hBmp = (HBITMAP)LoadImage(GetModuleHandle(NULL), "../Bmp/Man.bmp", IMAGE_BITMAP, 32, 32, LR_LOADFROMFILE);
				}
				else
				{
					hBmp = (HBITMAP)LoadImage(GetModuleHandle(NULL), "../Bmp/ManNo.bmp", IMAGE_BITMAP, 32, 32, LR_LOADFROMFILE);
				}
				
			}
			else
			{
				if (lpDis->itemData & 2)
				{
					hBmp = (HBITMAP)LoadImage(GetModuleHandle(NULL), "../Bmp/WoMan.bmp", IMAGE_BITMAP, 32, 32, LR_LOADFROMFILE);
				}
				else
				{
					hBmp = (HBITMAP)LoadImage(GetModuleHandle(NULL), "../Bmp/WoManNo.bmp", IMAGE_BITMAP, 32, 32, LR_LOADFROMFILE);
				}
			}

			HDC hMenDC = CreateCompatibleDC(lpDis->hDC);

			SelectObject(hMenDC, hBmp);

			BitBlt(lpDis->hDC, 0, lpDis->rcItem.top, 32, 32, hMenDC, 0, 0, SRCCOPY);

			DeleteObject(hBmp);
			DeleteDC(hMenDC);

			RECT rect = lpDis->rcItem;

			rect.left += 32;

			TCHAR szBuf[255] = TEXT("");

			SendMessage(lpDis->hwndItem, LB_GETTEXT, lpDis->itemID, (LPARAM)szBuf);

			DrawText(lpDis->hDC, szBuf, strlen(szBuf), &rect, DT_VCENTER | DT_SINGLELINE);

			SetBkColor(lpDis->hDC, RGB(255, 255, 255));
			SetTextColor(lpDis->hDC, RGB(0, 0, 0));
		}
	}

	return true;
}

BOOL OnMainTimer(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	static bool bFlag = false;
	int nCount = SendDlgItemMessage(hDlg, IDC_LIST1, LB_GETCOUNT, 0, 0);

	RECT rect = { 0, 0, 32, 32 };

	for (int i = 0; i < nCount; i++)
	{
		int nData = SendDlgItemMessage(hDlg, IDC_LIST1, LB_GETITEMDATA, i, 0);

		if (nData & 4)
		{
			rect.top = i * 32;
			rect.bottom = rect.top + 32;

			if (bFlag)
			{
				HBRUSH hBrush = CreateSolidBrush(RGB(255, 255, 255));
				FillRect(GetDC(GetDlgItem(hDlg, IDC_LIST1)), &(rect), hBrush);
				DeleteObject(hBrush);
			}
			else
			{
				InvalidateRect(GetDlgItem(hDlg, IDC_LIST1), &rect, TRUE);
			}

		}
	}

	bFlag = !bFlag;

	return TRUE;
}
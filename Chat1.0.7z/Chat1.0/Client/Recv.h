#pragma once

#include <Windows.h>
#include "CString.h"

class CRecv
{
public:
	CRecv();
	~CRecv();

	CString& GetMsg();

private:
	CString m_Msg;
};


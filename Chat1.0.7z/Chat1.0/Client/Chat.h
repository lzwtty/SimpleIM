#pragma once

#include "MsgMap.h"
#include "ChatWnd.h"
extern CList<CChatWnd> g_Chat;

DELCARE_DLGPROC(Chat)
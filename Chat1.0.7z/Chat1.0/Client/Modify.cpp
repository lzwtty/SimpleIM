#include "StdAfx.h"
#include "Modify.h"

BOOL OnModifyInitDialog(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnModifyCommand(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnModifyClose(HWND hDlg, WPARAM wParam, LPARAM lParam);

BEGIN_MSG_MAP(Modify)
	MAP(WM_INITDIALOG, OnModifyInitDialog)
	MAP(WM_COMMAND, OnModifyCommand)
	MAP(WM_CLOSE, OnModifyClose)
END_MSG_MAP()

IMPLEMENT_DLGPROC(Modify)


BOOL OnModifyInitDialog(HWND hDlg, WPARAM wParam, LPARAM lParam)
{

	return TRUE;
}

BOOL OnModifyClose(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	EndDialog(hDlg, WM_CLOSE);

	return TRUE;
}

BOOL OnModifyCommand(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	int nNty = HIWORD(wParam);
	int nID = LOWORD(wParam);

	static BOOL bFlag = false;

	if (nNty == BN_CLICKED)
	{
		if (nID == IDC_BTN_MOK)
		{
			PACK_MODIFY *pPack = new PACK_MODIFY;

			pPack->nNty = PROTO_MODIFY;
			GetWindowText(GetDlgItem(hDlg, IDC_EDIT_MNAME), pPack->szName, 20);
			GetWindowText(GetDlgItem(hDlg, IDC_EDIT_MPASS), pPack->szPass, 20);
			pPack->bSex = bFlag;

			send(g_Sock, (char*)pPack, sizeof(PACK_MODIFY), 0);
		}

		if (nID == IDC_RADIO_MMAN)
		{
			bFlag = true;
		}
		if (nID == IDC_RADIO_MWOMAN)
		{
			bFlag = false;
		}
	}

	return TRUE;
}
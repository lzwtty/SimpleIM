#pragma once

#include <WinSock2.h>
#include "resource.h"

typedef BOOL(*DLG_PFN)(HWND hDlg, WPARAM wParam, LPARAM lParam);

struct MSG_MAP
{
	UINT uMsg;
	DLG_PFN pfnDlg;
};

#define DELCARE_DLGPROC(name) BOOL CALLBACK name##Proc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

#define IMPLEMENT_DLGPROC(name)\
BOOL CALLBACK name##Proc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)\
{\
	MSG_MAP *pTemp = g_##name##MsgMap;\
\
	while (pTemp->uMsg)\
	{\
		if (pTemp->uMsg == uMsg)\
		{\
			return pTemp->pfnDlg(hDlg, wParam, lParam);\
		}\
\
		pTemp++;\
	}\
\
	return false;\
}

#define CALL_DLGPROC(name) name##Proc

#define BEGIN_MSG_MAP(name) MSG_MAP g_##name##MsgMap[] = {

#define MAP(msg, pfn) {msg, pfn},

#define END_MSG_MAP() {WM_NULL, NULL}};

#define CALL_MSG_MAP(name) g_##name##MsgMap

extern SOCKET g_Sock;

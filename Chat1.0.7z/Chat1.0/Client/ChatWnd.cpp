#include "ChatWnd.h"



CChatWnd::CChatWnd()
{
}


CChatWnd::~CChatWnd()
{
}

CChatWnd::DATA& CChatWnd::GetData()
{
	return m_Data;
}

bool CChatWnd::operator ==(const TCHAR *pStr)
{
	return m_Data.szUser == pStr;
}
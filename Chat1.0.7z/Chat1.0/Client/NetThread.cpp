#include "StdAfx.h"
#include "NetThread.h"
#include "ChatWnd.h"

int Login(DATA *pData);
int LoginRes(DATA *pData);
int CheckUserRes(DATA *pData);
int ListRes(DATA *pData);
int AddRes(DATA *pData);
int MyFriend(DATA *pData);
int AddFriend(DATA *pData);
int Logout(DATA *pData);
int Send(DATA *pData);

BEGIN_MAP(Client)
	MAP(PROTO_LOGIN_RES, LoginRes)
	MAP(PROTO_LOGIN_NTY, Login)
	MAP(PROTO_CHECH_USER_RES, CheckUserRes)
	MAP(PROTO_ALL_FRIEND_RES, ListRes)
	MAP(PROTO_ADD_FRIE_RES, AddRes)
	MAP(PROTO_ADD_FRIENDT, AddFriend)
	MAP(PROTO_FRIENDLIST_RES, MyFriend)
	MAP(PROTO_LOGOUT_NTY, Logout)
	MAP(PROTO_SEND, Send)
END_MAP()

IMPLEMENT_THREADPROC(Client)

CList<CChatWnd> g_Chat;

int Login(DATA *pData)
{
	PACK_CHECK_USER *pPack = (PACK_CHECK_USER *)pData->szBuf;

	int nIndex = SendMessage(GetDlgItem(g_Main, IDC_LIST1), LB_FINDSTRING, -1, (LPARAM)pPack->szUser);

	int nData = SendMessage(GetDlgItem(g_Main, IDC_LIST1), LB_GETITEMDATA, nIndex, 0);

	nData = nData | 2;

	SendMessage(GetDlgItem(g_Main, IDC_LIST1), LB_SETITEMDATA, nIndex, nData);

	delete pData;

	InvalidateRect(GetDlgItem(g_Main, IDC_LIST1), NULL, TRUE);

	return 0;
}

int LoginRes(DATA *pData)
{
	PACK_RES *pPack = (PACK_RES *)pData->szBuf;

	if(pPack->nRes == 0)
	{
		SendMessage(g_Login, WM_ERROR, NULL, NULL);
	}
	else
	{
		SendMessage(g_Login, WM_OK, NULL, NULL);
	}

	delete pData;

	return 0;
}

int CheckUserRes(DATA *pData)
{
	PACK_RES *pPack = (PACK_RES *)pData->szBuf;

	SendMessage(g_Regist, WM_CHECK, pPack->nRes, 0);

	delete pData;

	return 0;
}

int ListRes(DATA *pData)
{
	PACK_FRIENDLIST *pPack = (PACK_FRIENDLIST*)pData->szBuf;

	if (pPack->nSize > 1)
	{
		TCHAR szBuf[20] = "";
		int j = 0;
		int nCount = 0;
		for (int i = 0; '\0' != (szBuf[j] = pPack->szFriend[i]); i++, j++)
		{
			if (' ' == szBuf[j])
			{
				szBuf[j] = '\0';

				SendMessage(GetDlgItem(g_AddFriList, IDC_LIST_ADDFRIEND), LB_ADDSTRING, 0, (LPARAM)szBuf);
				SendMessage(GetDlgItem(g_AddFriList, IDC_LIST_ADDFRIEND), LB_SETITEMDATA, nCount, pPack->szFriend[pPack->nSize + nCount]);
				nCount++;
				j = -1;
			}
		}

		SendMessage(GetDlgItem(g_AddFriList, IDC_LIST_ADDFRIEND), LB_ADDSTRING, 0, (LPARAM)szBuf);
		SendMessage(GetDlgItem(g_AddFriList, IDC_LIST_ADDFRIEND), LB_SETITEMDATA, nCount, pPack->szFriend[pPack->nSize + nCount]);

		InvalidateRect(GetDlgItem(g_AddFriList, IDC_LIST_ADDFRIEND), NULL, TRUE);
	}
	delete pData;
	return 0;
}

int AddRes(DATA *pData)
{
	PACK_ADDFIREND_RES *pPack = (PACK_ADDFIREND_RES *)pData->szBuf;

	if (!(pPack->nRes))
	{
		MessageBox(NULL, "Refuse", pPack->szDest, MB_OK);
	}
	delete pData;
	return 0;
}

int MyFriend(DATA *pData)
{
	PACK_FRIENDLIST *pPack = (PACK_FRIENDLIST *)pData->szBuf;

	SendMessage(GetDlgItem(g_Main, IDC_LIST1), LB_RESETCONTENT, 0, 0);

	TCHAR szBuf[20] = "";
	int j = 0;
	int nCount = 0;

	int nNum = 0;
	TCHAR szUser[20] = "";
	TCHAR szName[20] = "";
	int z = 0;
	int x = 0;
	bool bFlag = false;

	g_Chat.Clerk();

	for (int i = 0; '\0' != (szBuf[j] = pPack->szFriend[i]); i++, j++)
	{
		if (' ' == pPack->szFriend[i])
		{
			szBuf[j] = 0;

			SendMessage(GetDlgItem(g_Main, IDC_LIST1), LB_ADDSTRING, 0, (LPARAM)szBuf);
			for (int y = 0; '\0' != szBuf[y]; y++)
			{
				if (')' == szBuf[y])
				{
					bFlag = false;
					szUser[z] = '\0';
					z = 0;
					break;
				}

				if (bFlag)
				{
					szUser[z] = szBuf[y];
					z++;
				}
				else
				{
					szName[x] = szBuf[y];
					x++;
				}

				if ('(' == szBuf[y])
				{
					bFlag = true;
					szName[x - 1] = '\0';
					x = 0;
				}
			}

			CList<CChatWnd>::Iterator iTemp = (g_Chat.AddEnd());
			(*iTemp).GetData().szName = szName;
			(*iTemp).GetData().szUser = szUser;
			if (pPack->szFriend[pPack->nSize + nCount * 2])
			{
				nNum = nNum | 1;
			}
			if (pPack->szFriend[pPack->nSize + nCount * 2 + 1])
			{
				nNum = nNum | 2;
			}
			SendMessage(GetDlgItem(g_Main, IDC_LIST1), LB_SETITEMDATA, nCount, (LPARAM)nNum);
			nCount++;

			nNum = 0;
			j = -1;
		}
	}

	if (pPack->szFriend[pPack->nSize + nCount * 2])
	{
		nNum = nNum | 1;
	}
	if (pPack->szFriend[pPack->nSize + nCount * 2 + 1])
	{
		nNum = nNum | 2;
	}

	SendMessage(GetDlgItem(g_Main, IDC_LIST1), LB_ADDSTRING, 0, (LPARAM)szBuf);
	for (int y = 0; '\0' != szBuf[y]; y++)
	{
		if (')' == szBuf[y])
		{
			bFlag = false;
			szUser[z] = '\0';
			z = 0;
			break;
		}

		if (bFlag)
		{
			szUser[z] = szBuf[y];
			z++;
		}
		else
		{
			szName[x] = szBuf[y];
			x++;
		}

		if ('(' == szBuf[y])
		{
			bFlag = true;
			szName[x - 1] = '\0';
			x = 0;
		}
	}

	CList<CChatWnd>::Iterator iTemp = (g_Chat.AddEnd());
	(*iTemp).GetData().szName = szName;
	(*iTemp).GetData().szUser = szUser;
	
	SendMessage(GetDlgItem(g_Main, IDC_LIST1), LB_SETITEMDATA, nCount, (LPARAM)nNum);

	InvalidateRect(GetDlgItem(g_Main, IDC_LIST1), NULL, TRUE);

	delete pData;
	return 0;
}

int AddFriend(DATA *pData)
{
	PACK_ADDFIREND *pPack = (PACK_ADDFIREND*)pData->szBuf;

	TCHAR szBuf[255] = "";

	wsprintf(szBuf, " %s want to be you Friend (accept?)", pPack->szSour);

	int nRes = MessageBox(NULL, szBuf, "AddFriend", MB_YESNO);

	PACK_ADDFIREND_RES *pNew = new PACK_ADDFIREND_RES;

	pNew->nNty = PROTO_ADD_FRIE_RES;

	strcpy(pNew->szDest, pPack->szDest);
	strcpy(pNew->szSour, pPack->szSour);

	if (IDNO == nRes)
	{
		pNew->nRes = 0;
	}
	if (IDYES == nRes)
	{
		pNew->nRes = 1;
	}

	send(pData->sock, (char*)pNew, sizeof(PACK_ADDFIREND_RES), 0);

	delete pNew;

	delete pData;

	return 0;
}

int Logout(DATA *pData)
{
	PACK_CHECK_USER *pPack = (PACK_CHECK_USER *)pData->szBuf;

	int nIndex = SendMessage(GetDlgItem(g_Main, IDC_LIST1), LB_FINDSTRING, -1, (LPARAM)pPack->szUser);

	int nData = SendMessage(GetDlgItem(g_Main, IDC_LIST1), LB_GETITEMDATA, nIndex, 0);

	if (nData & 2)
	{
		nData -= 2;
	}

	SendMessage(GetDlgItem(g_Main, IDC_LIST1), LB_SETITEMDATA, nIndex, nData);

	delete pData;

	InvalidateRect(GetDlgItem(g_Main, IDC_LIST1), NULL, TRUE);

	return 0;
}

int Send(DATA *pData)
{
	PACK_SEND *pPack = (PACK_SEND*)pData->szBuf;

	CList<CChatWnd>::Iterator iBegin = g_Chat.Begin();
	CList<CChatWnd>::Iterator iEnd = g_Chat.End();

	CList<CChatWnd>::Iterator iTemp = FindNode(iBegin, iEnd, pPack->szSour);

	if ((*iTemp).GetData().hWnd != NULL)
	{
		TCHAR szBuf[1024] = "";
		GetWindowText(GetDlgItem((*iTemp).GetData().hWnd, IDC_EDIT_CRECV), szBuf, 1024);

		if (!(0 == strcmp(szBuf, "")))
		{
			strcat(szBuf, "\r\n");
		}

		strcat(szBuf, pPack->szSour);
		strcat(szBuf, ":");
		strcat(szBuf, pPack->szBuf);

		SetWindowText(GetDlgItem((*iTemp).GetData().hWnd, IDC_EDIT_CRECV), szBuf);
	}
	else
	{

		(*((*iTemp).GetData().m_Recv.AddEnd())).GetMsg() = pPack->szBuf;
		TCHAR szBuf[40] = "";

		strcat(szBuf, (*iTemp).GetData().szName);
		strcat(szBuf, "(");
		strcat(szBuf, (*iTemp).GetData().szUser);
		strcat(szBuf, ")");
		int nIndex = SendDlgItemMessage(g_Main, IDC_LIST1, LB_FINDSTRING, -1, (LPARAM)szBuf);

		int nData = SendDlgItemMessage(g_Main, IDC_LIST1, LB_GETITEMDATA, nIndex, 0);

		nData = nData | 4;

		SendDlgItemMessage(g_Main, IDC_LIST1, LB_SETITEMDATA, nIndex, nData);
	}

	delete pData;

	return 0;
}
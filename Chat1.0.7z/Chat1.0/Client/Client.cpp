// Client.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "Main.h"

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.

	DialogBox(hInstance, MAKEINTRESOURCE(IDD_DLG_MAIN), NULL, CALL_DLGPROC(Main));

	return 0;
}




#include "StdAfx.h"
#include "AddFirList.h"

BOOL OnAddInitDialog(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnAddCommand(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnAddClose(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnAddDrawItem(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnAddMeasItem(HWND hDlg, WPARAM wParam, LPARAM lParam);

BEGIN_MSG_MAP(AddFriList)
	MAP(WM_INITDIALOG, OnAddInitDialog)
	MAP(WM_COMMAND, OnAddCommand)
	MAP(WM_MEASUREITEM, OnAddMeasItem)
	MAP(WM_DRAWITEM, OnAddDrawItem)
	MAP(WM_CLOSE, OnAddClose)
END_MSG_MAP()

IMPLEMENT_DLGPROC(AddFriList)

HWND g_AddFriList;

BOOL OnAddInitDialog(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	g_AddFriList = hDlg;

	SendDlgItemMessage(hDlg, IDC_LIST_ADDFRIEND, LB_SETITEMHEIGHT, 32, 0);

	return TRUE;
}

BOOL OnAddClose(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	DestroyWindow(hDlg);

	return TRUE;
}

BOOL OnAddCommand(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	int nNty = HIWORD(wParam);
	int nID = LOWORD(wParam);

	if (nNty == LBN_DBLCLK)
	{
		if (nID == IDC_LIST_ADDFRIEND)
		{
			int nIndex = SendDlgItemMessage(hDlg, IDC_LIST_ADDFRIEND, LB_GETCURSEL, 0, 0);

			TCHAR szBuf[55] = "";
			SendDlgItemMessage(hDlg, IDC_LIST_ADDFRIEND, LB_GETTEXT, nIndex, (LPARAM)szBuf);

			if (LB_ERR == SendDlgItemMessage(GetParent(hDlg), IDC_LIST1, LB_FINDSTRING, -1, (LPARAM)szBuf))
			{
				PACK_ADDFIREND *pPack = new PACK_ADDFIREND;

				pPack->nNty = PROTO_ADD_FRIENDT;

				int j = 0;
				bool bFlag = false;

				for (int i = 0; szBuf[i] != ')'; i++)
				{
					if (bFlag)
					{
						pPack->szDest[j] = szBuf[i];
						j++;
					}

					if (szBuf[i] == '(')
					{
						bFlag = true;
					}
				}

				pPack->szDest[j] = 0;

				GetWindowText(GetParent(hDlg), pPack->szSour, 20);

				send(g_Sock, (char*)pPack, sizeof(PACK_ADDFIREND), 0);
			}
			else
			{
				MessageBox(NULL, " You are already good friends.", "Error!", MB_OK);
			}

			
		}
	}

	return TRUE;
}

BOOL OnAddDrawItem(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	LPDRAWITEMSTRUCT lpDis = (LPDRAWITEMSTRUCT)lParam;

	if (lpDis->CtlType == ODT_LISTBOX)
	{
		if (lpDis->itemAction == ODA_DRAWENTIRE || ODA_SELECT == lpDis->itemAction)
		{
			HBRUSH hBrush = 0;
			if (lpDis->itemState & ODS_SELECTED)
			{
				hBrush = CreateSolidBrush(RGB(0, 0, 255));

				SetBkColor(lpDis->hDC, RGB(0, 0, 255));
				SetTextColor(lpDis->hDC, RGB(255, 255, 255));
			}
			else
			{
				hBrush = CreateSolidBrush(RGB(255, 255, 255));
			}

			FillRect(lpDis->hDC, &(lpDis->rcItem), hBrush);

			HBITMAP hBmp;

			if (lpDis->itemData)
			{
				hBmp = (HBITMAP)LoadImage(GetModuleHandle(NULL), "../Bmp/Man.bmp", IMAGE_BITMAP, 32, 32, LR_LOADFROMFILE);
			}
			else
			{
				hBmp = (HBITMAP)LoadImage(GetModuleHandle(NULL), "../Bmp/WoMan.bmp", IMAGE_BITMAP, 32, 32, LR_LOADFROMFILE);
			}

			HDC hMenDC = CreateCompatibleDC(lpDis->hDC);

			SelectObject(hMenDC, hBmp);

			BitBlt(lpDis->hDC, 0, lpDis->rcItem.top, 32, 32, hMenDC, 0, 0 ,SRCCOPY);

			DeleteObject(hBmp);
			DeleteDC(hMenDC);

			RECT rect = lpDis->rcItem;

			rect.left += 32;

			TCHAR szBuf[255] = TEXT("");

			SendMessage(lpDis->hwndItem, LB_GETTEXT, lpDis->itemID, (LPARAM)szBuf);

			DrawText(lpDis->hDC, szBuf, strlen(szBuf), &rect,  DT_VCENTER | DT_SINGLELINE);
		}
	}

	return true;
}

BOOL OnAddMeasItem(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	LPMEASUREITEMSTRUCT lpItem = (LPMEASUREITEMSTRUCT)lParam;

	lpItem->itemHeight = 32;

	return TRUE;
}
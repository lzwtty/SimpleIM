//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� Client.rc ʹ��
//
#define IDD_DLG_LOGIN                   101
#define IDD_DLG_REGISTER                102
#define IDD_DLG_MAIN                    103
#define IDD_DIALOG1                     106
#define IDD_DLG_ADDFRI                  106
#define IDD_DLG_CHAT                    111
#define IDD_DLG_MODIFY                  113
#define IDB_BITMAP1                     115
#define IDB_BITMAP_HEAD                 115
#define IDC_EDIT_LUSER                  1000
#define IDC_EDIT_LPASS                  1001
#define IDC_BTN_LOGIN                   1002
#define IDC_BTN_REGISTER                1003
#define IDC_EDIT_RUSER                  1004
#define IDC_EDIT_RPASS                  1005
#define IDC_BTN_ROK                     1006
#define IDC_RADIO_MAN                   1007
#define IDC_RADIO_WOMAN                 1008
#define IDC_BTN_MADDFRIEND              1008
#define IDC_LIST1                       1009
#define IDC_BTN_MODIFY                  1010
#define IDC_LIST_ADDFRIEND              1010
#define IDC_EDIT_RNAME                  1012
#define IDC_EDIT_CRECV                  1013
#define IDC_EDIT_CSEND                  1014
#define IDC_BTN_SEND                    1015
#define IDC_BTN_MOK                     1016
#define IDC_EDIT_MPASS                  1017
#define IDC_EDIT_MNAME                  1018
#define IDC_RADIO_MMAN                  1019
#define IDC_RADIO_MWOMAN                1020
#define IDC_EDIT3                       1021
#define IDC_EDIT_CUSER                  1021
#define IDC_EDIT_CNAME                  1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        116
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

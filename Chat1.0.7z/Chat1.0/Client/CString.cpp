#include "CString.h"

CString::CString()
{
	m_pStr = NULL;
}

CString::CString(const TCHAR *pStr)
{
	m_pStr = NULL;
	if (NULL != pStr)
	{
		Copy(pStr);
	}
}

CString::CString(const CString &r)
{
	m_pStr = NULL;
	if(!r.IsEmpty())
	{
		Copy(r.m_pStr);
	}
}

CString::~CString()
{
	Empty();
}


CString& CString::operator =(const TCHAR *pStr)
{
	Empty();
	if (NULL != pStr)
	{
		Copy(pStr);
	}

	return *this;
}

CString& CString::operator =(const CString &r)
{
	if (this != &r)
	{
		Empty();
		if (!r.IsEmpty())
		{
			Copy(r.m_pStr);
		}
	}

	return *this;
}

CString& CString::operator +=(const TCHAR *pStr)
{
	if (NULL != pStr)
	{
		Cat(pStr);
	}

	return *this;
}

CString& CString::operator +=(const CString &r)
{
	if (!r.IsEmpty())
	{
		Cat(r.m_pStr);
	}

	return *this;
}

bool CString::operator ==(const CString &r) const
{
	return *this == r.m_pStr;
}

bool CString::operator ==(const TCHAR *pStr) const
{
	if (NULL == pStr && NULL == m_pStr)
	{
		return true;
	}

	if (NULL != pStr && NULL != m_pStr)
	{
		for (int i = 0; pStr[i] == m_pStr[i]; i++)
		{
			if (pStr[i] == '\0')
			{
				return true;
			}
		}
	}

	return false;
}

bool CString::operator !=(const CString &r) const
{
	return !(*this == r.m_pStr);
}

bool CString::operator !=(const TCHAR *pStr) const
{
	return !(*this == pStr);
}

bool operator ==(const TCHAR *pStr, const CString &r)
{
	return r == pStr;
}

bool operator !=(const TCHAR *pStr, const CString &r)
{
	return r != pStr;
}

int CString::GetLength()
{
	if (NULL != m_pStr)
	{
		return GetLen(m_pStr);
	}
	else
	{
		return 0;
	}

}

CString::operator char*()
{
	return m_pStr;
}

int CString::GetLen(const TCHAR *pStr)
{
	int nLen = 0;
	for (; pStr[nLen] != '\0'; nLen++);
	return nLen;
}

void CString::Copy(const TCHAR *pStr)
{
	m_pStr = new TCHAR[GetLen(pStr) + 1];

	if (NULL != m_pStr)
	{
		for (int i = 0; '\0' != (m_pStr[i] = pStr[i]); i++);
	}
}

void CString::Cat(const TCHAR *pStr)
{
	TCHAR *pTemp = m_pStr;

	if (NULL != m_pStr)
	{
		m_pStr = new TCHAR[GetLen(pTemp) + GetLen(pStr) + 1];

		if (NULL != m_pStr)
		{
			int nLen = GetLen(pTemp);

			for (int i = 0; '\0' != (m_pStr[i] = pTemp[i]); i++);
			for (int i = 0; '\0' != (m_pStr[i + nLen] = pStr[i]); i++);
		}
	}
	else
	{
		Copy(pStr);
	}

}

bool CString::IsEmpty() const
{
	return m_pStr == NULL ? true : false;
}

void CString::Empty()
{
	if (NULL != m_pStr)
	{
		delete[] m_pStr;
		m_pStr = NULL;
	}
}
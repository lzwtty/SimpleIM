#include "StdAfx.h"
#include "Register.h"

BOOL OnRegInitDialog(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnRegClose(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnRegOk(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnRegCheck(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnRegCommand(HWND hDlg, WPARAM wParam, LPARAM lParam);

BEGIN_MSG_MAP(Register)
	MAP(WM_INITDIALOG, OnRegInitDialog)
	MAP(WM_COMMAND, OnRegCommand)
	MAP(WM_OK, OnRegOk)
	MAP(WM_CHECK, OnRegCheck)
	MAP(WM_CLOSE, OnRegClose)
END_MSG_MAP()

IMPLEMENT_DLGPROC(Register)

HWND g_Regist;
bool g_bFlag = false;

BOOL OnRegInitDialog(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	g_Regist = hDlg;
	return TRUE;
}

BOOL OnRegClose(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	EndDialog(hDlg, WM_CLOSE);
	
	return TRUE;
}

BOOL OnRegCommand(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	DWORD wNotifyCode = HIWORD(wParam);
	DWORD wID = LOWORD(wParam);

	static bool bSex = false;
	
	if(wNotifyCode == BN_CLICKED)
	{
		if(wID == IDC_BTN_ROK)
		{
			if(g_bFlag)
			{
				PACK_REG *pPack = NULL;
				
				do
				{
					pPack = new PACK_REG;
				}while(pPack == NULL);
				
				pPack->nNty = PROTO_REGIST;
				pPack->bSex = bSex;
				GetWindowText(GetDlgItem(hDlg, IDC_EDIT_RUSER), pPack->uUser.szName, 20);
				GetWindowText(GetDlgItem(hDlg, IDC_EDIT_RPASS), pPack->uUser.szPass, 20);
				GetWindowText(GetDlgItem(hDlg, IDC_EDIT_RNAME), pPack->szName, 20);
				
				send(g_Sock, (char*)pPack, sizeof(PACK_REG), 0);

				SetWindowText(GetDlgItem(GetParent(hDlg), IDC_EDIT_LUSER), pPack->uUser.szName);
				SetWindowText(GetDlgItem(GetParent(hDlg), IDC_EDIT_LPASS), pPack->uUser.szPass);
				
				delete pPack;

				SendMessage(hDlg, WM_OK, NULL, NULL);
			}
			else
			{
				MessageBox(NULL, "Error Input!", "Error", MB_OK);
			}
		}
		if(wID == IDC_RADIO_MAN)
		{
			bSex = true;
		}
		if(wID == IDC_RADIO_WOMAN)
		{
			bSex = false;
		}
	}

	if(wNotifyCode == EN_KILLFOCUS)
	{
		if(wID == IDC_EDIT_RUSER)
		{
			PACK_CHECK_USER *pPack = NULL;

			do 
			{
				pPack = new PACK_CHECK_USER;
			} while (pPack == NULL);

			pPack->nNty = PROTO_CHECH_USER;

			GetWindowText(GetDlgItem(hDlg, IDC_EDIT_RUSER), pPack->szUser, 20);

			send(g_Sock, (char*)pPack, sizeof(PACK_CHECK_USER), 0);

			delete pPack;
		}
	}
	
	return TRUE;
}

BOOL OnRegOk(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	EndDialog(hDlg, WM_OK);
	return TRUE;
}

BOOL OnRegCheck(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	HBITMAP hBmp;
	if(wParam)
	{
		hBmp = (HBITMAP)LoadImage(GetModuleHandle(NULL), "../Bmp/Ok.bmp", IMAGE_BITMAP, 20, 20, LR_LOADFROMFILE);
		g_bFlag = true;
	}
	else
	{
		g_bFlag = false;
		hBmp = (HBITMAP)LoadImage(GetModuleHandle(NULL), "../Bmp/No.bmp", IMAGE_BITMAP, 20, 20, LR_LOADFROMFILE);
	}

	HDC hMemDC = CreateCompatibleDC(GetDC(hDlg));

	SelectObject(hMemDC, hBmp);

	RECT rect;
	GetWindowRect(GetDlgItem(hDlg, IDC_EDIT_RUSER), &rect);

	POINT pt = {rect.right, rect.top};
	ScreenToClient(hDlg, &pt);

	BitBlt(GetDC(hDlg), pt.x + 5, pt.y, 20, 20, hMemDC, 0, 0, SRCCOPY);

	DeleteDC(hMemDC);
	DeleteObject(hBmp);

	return TRUE;
}
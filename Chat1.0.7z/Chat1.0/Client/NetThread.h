#pragma once

#include <windows.h>

#include "../Include/Handle.h"
#include "ChatWnd.h"
DELCARE_THREADPROC(Client)

extern HWND g_Login;
extern HWND g_Main;
extern HWND g_Regist;
extern HWND g_AddFriList;
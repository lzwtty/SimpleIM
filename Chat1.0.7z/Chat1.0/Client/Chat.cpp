#include "StdAfx.h"
#include "Chat.h"

BOOL OnChatInitDialog(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnChatCommand(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnChatClose(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnChatOk(HWND hDlg, WPARAM wParam, LPARAM lParam);

BEGIN_MSG_MAP(Chat)
	MAP(WM_INITDIALOG, OnChatInitDialog)
	MAP(WM_COMMAND, OnChatCommand)
	MAP(WM_CLOSE, OnChatClose)
	MAP(WM_OK, OnChatOk)
END_MSG_MAP()

IMPLEMENT_DLGPROC(Chat)

BOOL OnChatInitDialog(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	
	return TRUE;
}

BOOL OnChatClose(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	TCHAR szName[20] = "";
	GetWindowText(hDlg, szName, 20);

	CList<CChatWnd>::Iterator iBegin = g_Chat.Begin();
	CList<CChatWnd>::Iterator iEnd = g_Chat.End();

	CList<CChatWnd>::Iterator iTemp = FindNode(iBegin, iEnd, szName);

	if (!iTemp.IsEmpty())
	{
		(*iTemp).GetData().hWnd = NULL;
	}

	DestroyWindow(hDlg);

	return TRUE;
}

BOOL OnChatCommand(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	int nNty = HIWORD(wParam);
	int nID = LOWORD(wParam);

	if (BN_CLICKED == nNty)
	{
		if (nID == IDC_BTN_SEND)
		{
			PACK_SEND *pPack = new PACK_SEND;

			TCHAR szRecv[1024] = "";
			GetWindowText(GetDlgItem(hDlg, IDC_EDIT_CRECV), szRecv, 1024);
			GetWindowText(GetDlgItem(hDlg, IDC_EDIT_CSEND), pPack->szBuf, 255);

			if (!(0 == strcmp(pPack->szBuf, "")))
			{
				if(!(0 == strcmp(szRecv, "")))
				{
					strcat(szRecv, "\r\n");
				}

				pPack->nNty = PROTO_SEND;

				GetWindowText(GetParent(hDlg), pPack->szSour, 20);
				GetWindowText(hDlg, pPack->szDest, 20);

				strcat(szRecv, pPack->szSour);
				strcat(szRecv, ":");
				strcat(szRecv, pPack->szBuf);

				SetWindowText(GetDlgItem(hDlg, IDC_EDIT_CRECV), szRecv);
				SetWindowText(GetDlgItem(hDlg, IDC_EDIT_CSEND), "");

				send(g_Sock, (char*)pPack, sizeof(PACK_SEND), 0);
			}
			

			delete pPack;
		}
	}
	
	return TRUE;
}

BOOL OnChatOk(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	TCHAR szUser[20] = "";
	GetWindowText(hDlg, szUser, 20);

	CList<CChatWnd>::Iterator iBegin = g_Chat.Begin();
	CList<CChatWnd>::Iterator iEnd = g_Chat.End();

	CList<CChatWnd>::Iterator iTemp = FindNode(iBegin, iEnd, szUser);

	TCHAR szRecv[1024] = "";

	if (!((*iTemp).GetData().m_Recv.IsEmpty()))
	{
		CList<CRecv>::Iterator rBegin = (*iTemp).GetData().m_Recv.Begin();
		CList<CRecv>::Iterator rEnd = (*iTemp).GetData().m_Recv.End();
		bool bFlag = true;

		while (rBegin != rEnd)
		{
			if (bFlag)
			{
				bFlag = false;
			}
			else
			{
				strcat(szRecv, "\r\n");
			}

			strcat(szRecv, szUser);
			strcat(szRecv, ":");
			strcat(szRecv, (*rBegin).GetMsg());

			rBegin++;
		}

		SetWindowText(GetDlgItem(hDlg, IDC_EDIT_CRECV), szRecv);

		(*iTemp).GetData().m_Recv.Clerk();

		TCHAR szBuf[40] = "";

		strcat(szBuf, (*iTemp).GetData().szName);
		strcat(szBuf, "(");
		strcat(szBuf, (*iTemp).GetData().szUser);
		strcat(szBuf, ")");

		int nIndex = SendDlgItemMessage(GetParent(hDlg), IDC_LIST1, LB_FINDSTRING, -1, (LPARAM)szBuf);

		int nData = SendDlgItemMessage(GetParent(hDlg), IDC_LIST1, LB_GETITEMDATA, nIndex, 0);

		if (nData & 4)
		{
			nData = nData - 4;
		}

		SendDlgItemMessage(GetParent(hDlg), IDC_LIST1, LB_SETITEMDATA, nIndex, nData);

	}

	SetWindowText(GetDlgItem(hDlg, IDC_EDIT_CNAME), (TCHAR*)lParam);
	SetWindowText(GetDlgItem(hDlg, IDC_EDIT_CUSER), (TCHAR*)szUser);

	return true;
}
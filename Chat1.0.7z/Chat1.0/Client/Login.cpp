#include "StdAfx.h"
#include "Login.h"
#include "Register.h"

BOOL OnLoginInitDialog(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnLoginClose(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnLoginOk(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnLoginError(HWND hDlg, WPARAM wParam, LPARAM lParam);
BOOL OnLoginCommand(HWND hDlg, WPARAM wParam, LPARAM lParam);

BEGIN_MSG_MAP(Login)
	MAP(WM_INITDIALOG, OnLoginInitDialog)
	MAP(WM_COMMAND, OnLoginCommand)
	MAP(WM_CLOSE, OnLoginClose)
	MAP(WM_OK, OnLoginOk)
	MAP(WM_ERROR, OnLoginError)
END_MSG_MAP()

IMPLEMENT_DLGPROC(Login)

HWND g_Login;

BOOL OnLoginInitDialog(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	g_Login = hDlg;
	return TRUE;
}

BOOL OnLoginClose(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	EndDialog(hDlg, WM_CLOSE);

	return TRUE;
}

BOOL OnLoginCommand(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	int wNotifyCode = HIWORD(wParam);
	int wID = LOWORD(wParam);
	
	if(wNotifyCode == BN_CLICKED)
	{
		if(wID == IDC_BTN_LOGIN)
		{
			PACK_LOGIN *pPack = NULL;

			do 
			{
				pPack = new PACK_LOGIN;
			} while (pPack == NULL);

			pPack->nNty = PROTO_LOGIN;

			GetWindowText(GetDlgItem(hDlg, IDC_EDIT_LUSER), pPack->uUser.szName, 20);
			GetWindowText(GetDlgItem(hDlg, IDC_EDIT_LPASS), pPack->uUser.szPass, 20);

			send(g_Sock, (char*)pPack, sizeof(PACK_LOGIN), 0);

			delete pPack;
		}

		if(wID == IDC_BTN_REGISTER)
		{
			DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DLG_REGISTER), hDlg, CALL_DLGPROC(Register));
		}
		
	}

	return TRUE;
}

BOOL OnLoginOk(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	char szBuf[20] = "";
	GetWindowText(GetDlgItem(hDlg, IDC_EDIT_LUSER), szBuf, 20);

	SetWindowText(GetParent(hDlg), szBuf);

	EndDialog(hDlg, WM_OK);
	return TRUE;
}

BOOL OnLoginError(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	MessageBox(NULL, "Input Error!", "Error!", MB_OK);
	EndDialog(hDlg, WM_CLOSE);
	return TRUE;
}
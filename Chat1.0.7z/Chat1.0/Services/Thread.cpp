#include "pch.h"
#include "Thread.h"
#include "../Include/Protocol.h"
#include "../Include/Handle.h"
#include "../Include/CList.h"
#include "User.h"

CList<CUser> g_User;

int Login(DATA *pData);
int Resgister(DATA *pData);
int CheckUser(DATA *pData);
int AllFriend(DATA *pData);
int MyFriend(DATA *pData);
int AddFriendRes(DATA *pData);
int AddFriend(DATA *pData);
int Log(DATA *pData);
int Send(DATA *pData);
int Modify(DATA *pData);

BEGIN_MAP(Service)
	MAP(PROTO_LOGIN, Login)
	MAP(PROTO_REGIST, Resgister)
	MAP(PROTO_CHECH_USER, CheckUser)
	MAP(PROTO_ALL_FRIENDLIST, AllFriend)
	MAP(PROTO_FRIENDLIST, MyFriend)
	MAP(PROTO_ADD_FRIENDT, AddFriend)
	MAP(PROTO_ADD_FRIE_RES, AddFriendRes)
	MAP(PROTO_LOGOUT, Log)
	MAP(PROTO_SEND, Send)
	MAP(PROTO_MODIFY, Modify)
END_MAP()


IMPLEMENT_THREADPROC(Service)

int Login(DATA *pData)
{
	PACK_LOGIN *pPack = (PACK_LOGIN *)pData->szBuf;

	CList<CUser>::Iterator iBegin = g_User.Begin();
	CList<CUser>::Iterator iEnd = g_User.End();

	while (iBegin != iEnd)
	{
		if ((*iBegin).CheckUser(pPack->uUser.szName))
		{
			break;
		}

		iBegin++;
	}
	PACK_RES *pNew = new PACK_RES;
	pNew->nNty = PROTO_LOGIN_RES;
	pNew->nRes = 0;
	if (!(iBegin.IsEmpty()))
	{
		if ((*iBegin).GetData().m_strPass == (const TCHAR*)(pPack->uUser.szPass))
		{
			pNew->nRes = 1;

			Sleep(100);

			((*iBegin).GetData()).m_sSocket = pData->sock;
			((*iBegin).GetData()).m_bState = true;
			Log(pData);
			MyFriend(pData);
		}
	}

	send(pData->sock, (char*)pNew, sizeof(PACK_RES), 0);

	delete pNew;

	if (NULL != pData)
	{
		delete pData;
		pData = NULL;
	}

	return 0;
}

int Resgister(DATA *pData)
{
	PACK_REG *pPack = (PACK_REG *)pData->szBuf;

	CList<CUser>::Iterator iTemp = g_User.AddEnd();

	((*iTemp).GetData()).m_bSex = pPack->bSex;
	((*iTemp).GetData()).m_strUser = pPack->uUser.szName;
	((*iTemp).GetData()).m_strPass = pPack->uUser.szPass;
	((*iTemp).GetData()).m_strName = pPack->szName;

	if (NULL != pData)
	{
		delete pData;
		pData = NULL;
	}
	return 0;
}

int CheckUser(DATA *pData)
{
	PACK_CHECK_USER *pPack = (PACK_CHECK_USER *)pData->szBuf;

	CList<CUser>::Iterator iBegin = g_User.Begin();
	CList<CUser>::Iterator iEnd = g_User.End();

	while (iBegin != iEnd)
	{
		if ((*iBegin).CheckUser(pPack->szUser))
		{
			break;
		}

		iBegin++;
	}

	PACK_RES *pRes = new PACK_RES;

	pRes->nNty = PROTO_CHECH_USER_RES;

	if(iBegin != NULL)
	{
		pRes->nRes = 0;
	}
	else
	{
		pRes->nRes = 1;
	}

	send(pData->sock, (char*)pRes, sizeof(PACK_RES), 0);

	delete pRes;
	if (NULL != pData)
	{
		delete pData;
		pData = NULL;
	}

	return 0;
}

int AllFriend(DATA *pData)
{
	CString strFriList;

	CList<CUser>::Iterator iBegin = g_User.Begin();
	CList<CUser>::Iterator iEnd = g_User.End();

	int nCount = 0;
	while (iBegin != iEnd)
	{
		if ((*iBegin).GetData().m_bState && ((*iBegin).GetData().m_sSocket != pData->sock))
		{
			if (NULL != strFriList)
			{
				strFriList += " ";
			}

			strFriList += (*iBegin).GetData().m_strName;
			strFriList += "(";
			strFriList += (*iBegin).GetData().m_strUser;
			strFriList += ")";
			nCount++;
		}

		iBegin++;
	}

	PACK_FRIENDLIST *pPack = (PACK_FRIENDLIST*)new char[12 + strFriList.GetLength() + 1 + nCount];
	pPack->nSize = strFriList.GetLength() + 1;
	pPack->nCount = nCount;

	pPack->nNty = PROTO_ALL_FRIEND_RES;

	if (!(strFriList.IsEmpty()))
	{
		strcpy(pPack->szFriend, strFriList);
	}

	pPack->szFriend[pPack->nSize - 1] = '\0';

	iBegin = g_User.Begin();

	
	for (int i = 0; iBegin != iEnd; iBegin++)
	{
		if ((*iBegin).GetData().m_bState && ((*iBegin).GetData().m_sSocket != pData->sock))
		{
			pPack->szFriend[pPack->nSize + i] = (*iBegin).GetData().m_bSex;
			i++;
		}
	}

	send(pData->sock, (char*)pPack, 12 + pPack->nSize + nCount, 0);

	delete pPack;
	if (NULL != pData)
	{
		delete pData;
		pData = NULL;
	}
	return 0;
}

int MyFriend(DATA *pData)
{
	CList<CUser>::Iterator iBegin = g_User.Begin();
	CList<CUser>::Iterator iEnd = g_User.End();

	int nCount = 0;
	while (iBegin != iEnd)
	{
		if ((*iBegin).GetData().m_sSocket == pData->sock)
		{
			break;
		}

		iBegin++;
	}

	char *pTemp = (*iBegin).GetData().m_strFriend;

	if (NULL != pTemp)
	{
		CString strFriend;
		int i = 0;
		int j = 0;
		TCHAR szTemp[20] = "";
		bool bFlag = false;
		nCount = 0;
		for (int i = 0; pTemp[i] != 0; i++)
		{
			if (')' == pTemp[i])
			{
				bFlag = false;
				szTemp[j] = '\0';

				j = 0;

				iBegin = g_User.Begin();

				while (iBegin != iEnd)
				{
					if ((*iBegin).CheckUser(szTemp))
					{
						if (!(strFriend.IsEmpty()))
						{
							strFriend += " ";
						}

						strFriend += (*iBegin).GetData().m_strName;
						strFriend += "(";
						strFriend += (*iBegin).GetData().m_strUser;
						strFriend += ")";
						break;
					}

					iBegin++;
				}

				nCount++;
			}

			if (bFlag)
			{
				szTemp[j] = pTemp[i];
				j++;
			}

			if ('(' == pTemp[i])
			{
				bFlag = true;
			}
		}


		PACK_FRIENDLIST *pPack = (PACK_FRIENDLIST*)new char[12 + strFriend.GetLength() + 1 + nCount * 2];
		pPack->nSize = strFriend.GetLength() + 1;
		pPack->nCount = nCount;

		pPack->nNty = PROTO_FRIENDLIST_RES;

		if (!(strFriend.IsEmpty()))
		{
			strcpy(pPack->szFriend, strFriend);
		}

		pPack->szFriend[pPack->nSize - 1] = '\0';

		pTemp = strFriend;

		nCount = 0;
		j = 0;
		bFlag = false;
		for (int i = 0; pTemp[i] != 0; i++)
		{
			if (')' == pTemp[i])
			{
				bFlag = false;
				szTemp[j] = '\0';

				j = 0;

				iBegin = g_User.Begin();

				while (iBegin != iEnd)
				{
					if ((*iBegin).CheckUser(szTemp))
					{
						pPack->szFriend[pPack->nSize + nCount * 2] = (*iBegin).GetData().m_bSex;
						pPack->szFriend[pPack->nSize + nCount * 2 + 1] = (*iBegin).GetData().m_bState;
						break;
					}

					iBegin++;
				}

				nCount++;
			}

			if (bFlag)
			{
				szTemp[j] = pTemp[i];
				j++;
			}

			if ('(' == pTemp[i])
			{
				bFlag = true;
			}
		}

		send(pData->sock, (char*)pPack, 12 + pPack->nSize + (nCount + 1)* 2, 0);
		delete pPack;
	}

	if (PROTO_FRIENDLIST == *(int*)pData->szBuf)
	{
		if (NULL != pData)
		{
			delete pData;
			pData = NULL;
		}
	}
	return 0;
}

int AddFriend(DATA *pData)
{
	PACK_ADDFIREND *pPack = (PACK_ADDFIREND *)pData->szBuf;

	CList<CUser>::Iterator iBegin = g_User.Begin();
	CList<CUser>::Iterator iEnd = g_User.End();

	while (iBegin != iEnd)
	{
		if ((*iBegin).CheckUser(pPack->szDest))
		{
			break;
		}

		iBegin++;
	}

	send((*iBegin).GetData().m_sSocket, (char*)pPack, sizeof(PACK_ADDFIREND), 0);
	if (NULL != pData)
	{
		delete pData;
		pData = NULL;
	}
	return 0;
}

int AddFriendRes(DATA *pData)
{
	PACK_ADDFIREND_RES *pPack = (PACK_ADDFIREND_RES *)pData->szBuf;

	CList<CUser>::Iterator iBegin = g_User.Begin();
	CList<CUser>::Iterator iEnd = g_User.End();

	CList<CUser>::Iterator iDest;
	CList<CUser>::Iterator iSour;

	while (iBegin != iEnd)
	{
		if ((*iBegin).CheckUser(pPack->szDest))
		{
			iDest = iBegin;
		}

		if ((*iBegin).CheckUser(pPack->szSour))
		{
			iSour = iBegin;
		}

		iBegin++;
	}

	if (pPack->nRes)
	{
		if (!(*iDest).GetData().m_strFriend.IsEmpty())
		{
			(*iDest).GetData().m_strFriend += " ";
		}

		(*iDest).GetData().m_strFriend += "(";
		(*iDest).GetData().m_strFriend += (*iSour).GetData().m_strUser;
		(*iDest).GetData().m_strFriend += ")";

		if (!(*iSour).GetData().m_strFriend.IsEmpty())
		{
			(*iSour).GetData().m_strFriend += " ";
		}

		(*iSour).GetData().m_strFriend += "(";
		(*iSour).GetData().m_strFriend += (*iDest).GetData().m_strUser;
		(*iSour).GetData().m_strFriend += ")";


	}

	send((*iSour).GetData().m_sSocket, (char*)pPack, sizeof(PACK_ADDFIREND_RES), 0);

	if (pPack->nRes)
	{
		Sleep(100);
		pData->sock = (*iSour).GetData().m_sSocket;

		MyFriend(pData);

		pData->sock = (*iDest).GetData().m_sSocket;

		MyFriend(pData);
	}

	if (NULL != pData)
	{
		delete pData;
		pData = NULL;
	}

	return 0;
}

int Log(DATA *pData)
{
	CList<CUser>::Iterator iBegin = g_User.Begin();
	CList<CUser>::Iterator iEnd = g_User.End();
	CList<CUser>::Iterator iTemp;
	int nCount = 0;
	while (iBegin != iEnd)
	{
		if ((*iBegin).GetData().m_sSocket == pData->sock)
		{
			break;
		}

		iBegin++;
	}
	iTemp = iBegin;

	if (!(iTemp.IsEmpty()))
	{
		char *pTemp = (*iBegin).GetData().m_strFriend;

	if ((*(int*)pData->szBuf) == PROTO_LOGIN)
	{
		(*iTemp).GetData().m_bState = true;
	}
	if ((*(int*)pData->szBuf) == PROTO_LOGOUT)
	{
		(*iTemp).GetData().m_bState = false;
	}

	if (NULL != pTemp)
	{

		pTemp = (*iBegin).GetData().m_strFriend;

		TCHAR szTemp[20] = "";
		bool bFlag = false;
		int j = 0;

		char szUser[40] = "";

		strcat(szUser, (*iBegin).GetData().m_strName);
		strcat(szUser, "(");
		strcat(szUser, (*iBegin).GetData().m_strUser);
		strcat(szUser, ")");

		PACK_CHECK_USER *pPack = NULL;
		for (int i = 0; pTemp[i] != 0; i++)
		{
			if (')' == pTemp[i])
			{
				bFlag = false;
				szTemp[j] = '\0';

				j = 0;

				iBegin = g_User.Begin();

				while (iBegin != iEnd)
				{
					if ((*iBegin).CheckUser(szTemp))
					{
						pPack = new PACK_CHECK_USER;
						if ((*(int*)pData->szBuf) == PROTO_LOGIN)
						{
							pPack->nNty = PROTO_LOGIN_NTY;
						}
						if ((*(int*)pData->szBuf) == PROTO_LOGOUT)
						{
							pPack->nNty = PROTO_LOGOUT_NTY;
						}
						strcpy(pPack->szUser, szUser);

						send((*iBegin).GetData().m_sSocket, (char*)pPack, sizeof(PACK_CHECK_USER), 0);

						break;
					}

					iBegin++;
				}

			}

			if (bFlag)
			{
				szTemp[j] = pTemp[i];
				j++;
			}

			if ('(' == pTemp[i])
			{
				bFlag = true;
			}
		}

	}
	}
	
	if (PROTO_LOGOUT == *(int*)pData->szBuf)
	{
		if (NULL != pData)
		{
			delete pData;
			pData = NULL;
		}
	}
	return 0;
}

int Send(DATA *pData)
{
	PACK_SEND *pPack = (PACK_SEND*)pData->szBuf;

	CList<CUser>::Iterator iBegin = g_User.Begin();
	CList<CUser>::Iterator iEnd = g_User.End();
	CList<CUser>::Iterator iDest;
	CList<CUser>::Iterator iSour;
	while (iBegin != iEnd)
	{
		if ((*iBegin).CheckUser(pPack->szDest))
		{
			iDest = iBegin;
		}
		if ((*iBegin).CheckUser(pPack->szSour))
		{
			iSour = iBegin;
		}

		iBegin++;
	}

	send((*iDest).GetData().m_sSocket, (char*)pPack, sizeof(PACK_SEND), 0);

	if (NULL != pData)
	{
		delete pData;
		pData = NULL;
	}
	return 0;
}

int Modify(DATA *pData)
{
	PACK_MODIFY *pPack = (PACK_MODIFY*)pData->szBuf;

	CList<CUser>::Iterator iBegin = g_User.Begin();
	CList<CUser>::Iterator iEnd = g_User.End();

	while (iBegin != iEnd)
	{
		if ((*iBegin).GetData().m_sSocket == pData->sock)
		{
			break;
		}

		iBegin++;
	}

	(*iBegin).GetData().m_bSex = pPack->bSex;
	(*iBegin).GetData().m_strPass = pPack->szPass;
	(*iBegin).GetData().m_strName = pPack->szName;

	char *pTemp = (*iBegin).GetData().m_strFriend;

	if (NULL != pTemp)
	{
		char szTemp[20] = "";
		int j = 0;
		bool bFlag = false;
		for (int i = 0; pTemp[i] != 0; i++)
		{
			if (')' == pTemp[i])
			{
				bFlag = false;
				szTemp[j] = '\0';

				j = 0;

				iBegin = g_User.Begin();

				while (iBegin != iEnd)
				{
					if ((*iBegin).CheckUser(szTemp))
					{
						pData->sock = (*iBegin).GetData().m_sSocket;
						MyFriend(pData);
						break;
					}

					iBegin++;
				}
			}

			if (bFlag)
			{
				szTemp[j] = pTemp[i];
				j++;
			}

			if ('(' == pTemp[i])
			{
				bFlag = true;
			}
		}
	}
	if (NULL != pData)
	{
		delete pData;
		pData = NULL;
	}
	return 0;
}
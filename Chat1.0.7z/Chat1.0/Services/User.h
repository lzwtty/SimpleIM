#pragma once

#include "CString.h"

class CUser
{
public:
	CUser();
	~CUser();

	struct DATA
	{
		DATA();

		CString m_strUser;
		CString m_strPass;
		CString m_strName;
		CString m_strFriend;
		bool m_bState;
		bool m_bSex;
		SOCKET m_sSocket;
	};

	DATA& GetData();

	bool CheckUser(TCHAR *pStr) const;

	bool operator ==(const TCHAR *pStr) const;
	bool operator ==(const CString &r) const;
private: 
	DATA m_Data;
};


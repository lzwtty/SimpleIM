#pragma once

#include <Windows.h>

class CString
{
public:
	CString();
	CString(const TCHAR *pStr);
	CString(const CString &r);
	~CString();

	CString& operator =(const TCHAR *pStr);
	CString& operator =(const CString &r);
	CString& operator +=(const TCHAR *pStr);
	CString& operator +=(const CString &r);

	bool operator ==(const CString &r) const;
	bool operator ==(const TCHAR *pStr) const;
	bool operator !=(const CString &r) const;
	bool operator !=(const TCHAR *pStr) const;

	friend bool operator ==(const TCHAR *pStr, const CString &r);
	friend bool operator !=(const TCHAR *pStr, const CString &r);

	bool IsEmpty() const;
	void Empty();

	int GetLength();
	operator char*();

private:
	int GetLen(const TCHAR *pStr);
	void Copy(const TCHAR *pStr);
	void Cat(const TCHAR *pStr);

private:
	TCHAR *m_pStr;
};
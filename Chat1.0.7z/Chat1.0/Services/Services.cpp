﻿// Services.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "pch.h"
#include "Thread.h"


int main(int argc, char* argv[])
{
	WSADATA wd;
	WSAStartup(0x0202, &wd);

	SOCKET sockListen = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	if (INVALID_SOCKET == sockListen)
	{
		closesocket(sockListen);
		WSACleanup();
		cout << "socket Error : " << GetLastError() << endl;
		return -1;
	}

	SOCKADDR_IN sockAddr;
	sockAddr.sin_family = AF_INET;
	sockAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	sockAddr.sin_port = htons(4396);

	if (SOCKET_ERROR == bind(sockListen, (sockaddr*)&sockAddr, sizeof(SOCKADDR_IN)))
	{
		closesocket(sockListen);
		WSACleanup();
		cout << "bind Error : " << GetLastError() << endl;
		return -1;
	}

	if (SOCKET_ERROR == listen(sockListen, 3))
	{
		closesocket(sockListen);
		WSACleanup();
		cout << "listen Error : " << GetLastError() << endl;

		return -1;
	}

	DWORD dwThreadID = 0;
	while (true)
	{
		SOCKET sockCLient = accept(sockListen, NULL, NULL);

		cout << "Connect :" << sockCLient << endl;

		if (INVALID_SOCKET != sockCLient)
		{
			CloseHandle(CreateThread(NULL, NULL, CALL_THREADPROC(Service), (LPVOID)sockCLient, 0, &dwThreadID));
		}
	}

	WSACleanup();
	return 0;
}

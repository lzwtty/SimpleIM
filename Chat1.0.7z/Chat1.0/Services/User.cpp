#include "pch.h"
#include "User.h"


CUser::CUser()
{

}


CUser::~CUser()
{
}

CUser::DATA::DATA()
{
	m_bSex = false;
	m_bState = false;
	m_sSocket = 0;
}

CUser::DATA& CUser::GetData()
{
	return m_Data;
}

bool CUser::operator ==(const TCHAR *pStr) const
{
	return m_Data.m_strName == pStr;
}

bool CUser::operator ==(const CString &r) const
{
	return m_Data.m_strName == r;
}

bool CUser::CheckUser(TCHAR *pStr) const
{
	return m_Data.m_strUser == pStr;
}
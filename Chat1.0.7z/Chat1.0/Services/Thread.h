#pragma once

#include "../Include/Handle.h"

DELCARE_THREADPROC(Service)